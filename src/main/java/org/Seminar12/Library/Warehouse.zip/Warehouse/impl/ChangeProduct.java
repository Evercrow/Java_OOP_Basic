package org.Seminar12.Library.Warehouse.impl;

public interface ChangeProduct {
    public void decreaseCount(int amount);
    public void increaseCount(int amount);
}
